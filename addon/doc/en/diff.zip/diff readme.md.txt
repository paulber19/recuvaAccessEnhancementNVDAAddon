readme.md
diff between version 1.9.1 (<) and version 1.10 (>)
8,9c8,9
< 	* minimum NVDA version: 2023.1
< 	* last tested NVDA version: 2024.4
---
> 	* minimum NVDA version: 2024.1
> 	* last tested NVDA version: 2025.1
25c25
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/recuvaAccessEnhancement/recuvaAccessEnhancement-1.9.1.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/recuvaAccessEnhancement/recuvaAccessEnhancement-1.10.nvda-addon
