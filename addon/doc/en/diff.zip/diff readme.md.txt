readme.md
diff between version 1.7 (<) and version 1.8 (>)
8,9c8,9
< 	* minimum NVDA version: 2020.4
< 	* last tested NVDA version: 2023.1
---
> 	* minimum NVDA version: 2022.1
> 	* last tested NVDA version: 2024.1
25c25
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/recuvaAccessEnhancement/recuvaAccessEnhancement-1.7.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/recuvaAccessEnhancement/recuvaAccessEnhancement-1.8.nvda-addon
