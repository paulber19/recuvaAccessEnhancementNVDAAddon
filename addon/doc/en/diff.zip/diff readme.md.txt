readme.md
diff between version 1.10 (<) and version 1.11 (>)
8,9c8,9
< 	* minimum NVDA version: 2024.1
< 	* last tested NVDA version: 2025.1
---
> 	* minimum NVDA version: 2025.1
> 	* last tested NVDA version: 2026.1
25c25
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/recuvaAccessEnhancement/recuvaAccessEnhancement-1.10.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/recuvaAccessEnhancement/recuvaAccessEnhancement-1.11.nvda-addon
